from django.contrib import admin
#from .models import USer
#admin.site.register(USer)

# Register your models here.
